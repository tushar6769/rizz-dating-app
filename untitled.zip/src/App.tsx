/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  Sparkles, 
  MessageCircle, 
  Activity, 
  RotateCcw, 
  Heart, 
  TrendingUp, 
  ShieldCheck, 
  Compass, 
  HelpCircle,
  Award,
  BookmarkCheck,
  Award as BioIcon,
  ChevronsRight,
  ChevronRight,
  X,
  Plus
} from 'lucide-react';
import { ReplyGenerator } from './components/ReplyGenerator';
import { ChatAnalyzer } from './components/ChatAnalyzer';
import { ChatReviver } from './components/ChatReviver';
import { OpenerGenerator } from './components/OpenerGenerator';
import { BioWriter } from './components/BioWriter';
import { SavedResponses, SavedItem } from './components/SavedResponses';
import { motion, AnimatePresence } from 'motion/react';

type ActiveTab = 'replies' | 'openers' | 'bios' | 'analyzer' | 'reviver' | 'saved';

const COACH_PRO_TIPS = [
  "Rule #1 of text chemistry: Mirror response times, but make yours slightly more carefree.",
  "If they send you direct questions, they are invested. Avoid giving long multi-paragraph reviews.",
  "Never ask 'How was your day?'. Instead use 'What was the most chaotic thing that happened to you today?'",
  "A double-text isn't a crime, but a triple-text is a call for emotional probation.",
  "Bring up inside jokes rapidly. Shared history is the shortest path to chemistry.",
  "Punctuation matters. A cold '.' instead of an '!' or absolute absence of punctuation indicates a mood shift.",
  "Move the chat from dating app to WhatsApp/iMessage within 12 exchanges. Otherwise, it becomes an infinite pen-pal trap.",
  "Avoid self-deprecating humor until they are already obsessed with you. Keep the frame confident first.",
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('replies');
  const [customLogs, setCustomLogs] = useState<string[]>([
    "Coach RizzFlow active and ready to calibrate charm metrics.",
    "System check: Anti-cringe filters loaded at 100% capacity.",
  ]);
  const [showFaq, setShowFaq] = useState(false);
  const [savedList, setSavedList] = useState<SavedItem[]>([]);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(0);

  // Load saved item vault on mount
  useEffect(() => {
    try {
      const items = localStorage.getItem('rizzflow_saved_vault');
      if (items) {
        setSavedList(JSON.parse(items));
      }

      const completed = localStorage.getItem('rizzflow_completed_onboarding');
      if (!completed) {
        setShowOnboarding(true);
      }
    } catch (e) {
      console.warn('Could not read localStorage parameters', e);
    }
  }, []);

  const addLog = (log: string) => {
    setCustomLogs((prev) => [
      `[${new Date().toLocaleTimeString()}] ${log}`,
      ...prev.slice(0, 7),
    ]);
  };

  const handleSaveResponse = (reply: { text: string; category: string }) => {
    const isAlreadySaved = savedList.some((item) => item.text.trim() === reply.text.trim());
    if (isAlreadySaved) {
      addLog(`"${reply.text.slice(0, 20)}..." is already in your Rizz Vault.`);
      return;
    }

    const newItem: SavedItem = {
      id: `saved_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      text: reply.text,
      category: reply.category,
      savedAt: new Date().toISOString()
    };

    const updated = [...savedList, newItem];
    setSavedList(updated);
    localStorage.setItem('rizzflow_saved_vault', JSON.stringify(updated));
    addLog(`Successfully saved item in Vault: "${reply.text.slice(0, 20)}..."`);
  };

  const handleRemoveSavedItem = (id: string) => {
    const updated = savedList.filter((item) => item.id !== id);
    setSavedList(updated);
    localStorage.setItem('rizzflow_saved_vault', JSON.stringify(updated));
    addLog('Removed reply entry from Vault.');
  };

  const completeOnboarding = () => {
    localStorage.setItem('rizzflow_completed_onboarding', 'true');
    setShowOnboarding(false);
    addLog('Calibrated and ready to text! Completed RizzFlow onboarding program.');
  };

  const onboardingSlides = [
    {
      title: "Get Better Replies",
      description: "Paste messages or upload chat screenshots. RizzFlow uses custom multimodal scanner to evaluate attraction levels, spot green flags, and suggest your next clever text instantly.",
      stat: "94% Reply Rate Lift",
      colorClass: "from-pink-500 to-indigo-500"
    },
    {
      title: "Never Run Out Of Rizz",
      description: "Feed targets' bio context, listed interests, or photo activities to draft fascinating personalized icebreakers and hooks. No cheesiness, pure social calibrated confidence.",
      stat: "100+ Bespoke Starters",
      colorClass: "from-purple-500 to-orange-500"
    },
    {
      title: "Standout Bio Architect",
      description: "Write premium, custom dating profiles formatted beautifully with modular inline text editors. Align yourself to trending moods like Sarcasm, Gym, Luxury Lifestyle, and Bold Alpha.",
      stat: "3x More Matches Daily",
      colorClass: "from-orange-500 to-rose-500"
    }
  ];

  const currentTip = COACH_PRO_TIPS[Math.floor(Date.now() / 60000) % COACH_PRO_TIPS.length];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans tracking-normal selection:bg-pink-500 selection:text-white relative overflow-hidden pb-24">
      {/* Background radial glowing ambient blur meshes */}
      <div className="absolute top-[-300px] left-[-200px] w-[650px] h-[650px] bg-indigo-500/10 rounded-full blur-[170px] pointer-events-none"></div>
      <div className="absolute top-[20%] right-[-100px] w-[550px] h-[550px] bg-rose-500/5 rounded-full blur-[150px] pointer-events-none"></div>
      <div className="absolute bottom-[-100px] left-[15%] w-[650px] h-[650px] bg-teal-500/5 rounded-full blur-[160px] pointer-events-none"></div>

      {/* Onboarding Overlay Shield */}
      {showOnboarding && (
        <div className="fixed inset-0 bg-slate-950/90 flex items-center justify-center p-4 z-55 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-[32px] w-full max-w-xl p-8 relative overflow-hidden shadow-2xl">
            <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${onboardingSlides[onboardingStep].colorClass}`}></div>

            <button 
              onClick={completeOnboarding}
              className="absolute top-6 right-6 p-2 rounded-full bg-slate-950/60 hover:bg-slate-850 hover:text-white text-slate-400 transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Slide Body */}
            <div className="mt-4 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-pink-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-pink-500/10 mb-6">
                <Flame className="w-8 h-8 text-white animate-pulse" />
              </div>

              <span className="text-[11px] font-mono tracking-widest text-pink-400 uppercase font-bold bg-pink-500/10 px-3 py-1 rounded-full border border-pink-500/20 mb-3">
                RizzFlow Calibration Academy
              </span>

              <h3 className="text-2xl font-extrabold text-white tracking-tight mb-4">
                {onboardingSlides[onboardingStep].title}
              </h3>

              <p className="text-sm text-slate-300 leading-relaxed mb-6 max-w-sm">
                {onboardingSlides[onboardingStep].description}
              </p>

              {/* Stat callout badge */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-850 flex items-center justify-center gap-2 mb-8 w-full max-w-xs shadow-inner">
                <Sparkles className="w-4 h-4 text-orange-400 animate-bounce" />
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-350">
                  {onboardingSlides[onboardingStep].stat}
                </span>
              </div>

              {/* Stepper dots */}
              <div className="flex gap-2.5 mb-8">
                {onboardingSlides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setOnboardingStep(idx)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      idx === onboardingStep ? 'w-8 bg-pink-500' : 'w-2 bg-slate-850 hover:bg-slate-700'
                    }`}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="flex gap-3 w-full">
                <button
                  type="button"
                  onClick={completeOnboarding}
                  className="flex-1 py-3 text-xs font-bold text-slate-400 hover:text-white bg-slate-950 border border-slate-850 hover:border-slate-750 transition-all rounded-2xl cursor-pointer"
                >
                  Skip Schooling
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (onboardingStep < onboardingSlides.length - 1) {
                      setOnboardingStep(onboardingStep + 1);
                    } else {
                      completeOnboarding();
                    }
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-pink-500 to-indigo-600 hover:from-pink-650 hover:to-indigo-650 text-white font-bold text-xs rounded-2xl transition-all shadow-md flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>{onboardingStep === onboardingSlides.length - 1 ? 'Unlock My RizzFlow' : 'Next Lesson'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 relative z-10">
        
        {/* Top Navbar Header */}
        <header className="flex items-center justify-between py-5 border-b border-slate-900/80 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-pink-500/10">
              <Flame className="w-5.5 h-5.5 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold tracking-tight text-white font-sans">
                  Rizz<span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-indigo-400">Flow</span>
                </span>
                <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 text-[9px] font-mono text-indigo-300 uppercase font-semibold border border-indigo-500/20">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-500 tracking-wide font-mono">Dating Texting Strategy & Creative Suite</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowFaq(!showFaq)}
              className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-905/60 hover:bg-slate-800 text-slate-350 border border-slate-800 transition-all flex items-center gap-1.5 cursor-pointer select-none"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Calibrator FAQ</span>
            </button>
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-green-500/10 rounded-full border border-green-500/20">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping"></span>
              <span className="text-[10px] font-mono text-green-300">Charm Engine Primed</span>
            </div>
          </div>
        </header>

        {/* Pro Tip Ticker strip */}
        <div className="p-4 bg-gradient-to-r from-indigo-950/20 via-slate-900/60 to-rose-950/10 rounded-2xl border border-slate-900 mb-8 flex items-start gap-3 shadow-sm select-none">
          <div className="p-1 px-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-mono text-[9px] font-bold uppercase shrink-0 mt-0.5 animate-pulse">
            Quick Strategy
          </div>
          <p className="text-xs text-slate-300 leading-normal flex-1 font-sans">
            "{currentTip}"
          </p>
        </div>

        {/* FAQ Accordion container */}
        {showFaq && (
          <div className="mb-8 p-6 bg-slate-900 border border-slate-800 rounded-3xl shadow-xl transition-all">
            <h3 className="text-sm font-bold text-white mb-4 uppercase tracking-wider font-mono">Dating Coach FAQ & Calibration Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-400 leading-relaxed">
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-900">
                <p className="font-bold text-slate-200 mb-1">Q: How do I save my draft templates or openers?</p>
                <p>A: Simply press the "Save" chip right beside your copies option, and it automatically syncs with your high-value local Rizz Vault storage tab.</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-900">
                <p className="font-bold text-slate-200 mb-1">Q: What if they reply with a super dry text like "lol" or "K"?</p>
                <p>A: Switch to the Resuscitation tab immediately. Select "Dry Texting", insert notes, and let RizzFlow craft humorous playballs to reset context without defense.</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-900">
                <p className="font-bold text-slate-200 mb-1">Q: Can I scan conversation screenshots on my phone?</p>
                <p>A: Yes! Use the Vibe check tab, click/drag or capture JPEG/PNG crop screenshots. The multimodal model reads who says what and reports investment percentage index.</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-900">
                <p className="font-bold text-slate-200 mb-1">Q: How does the bio builder work?</p>
                <p>A: Feed traits, occupation, passions, and toggle target styles. You can then edit individual lines in-page inside the card before copying.</p>
              </div>
            </div>
          </div>
        )}

        {/* Bottom Platform/App switcher for desktop viewport header layout */}
        <div className="hidden lg:flex items-center justify-between p-1 bg-slate-950 border border-slate-900 rounded-2xl mb-8 max-w-4xl mx-auto shadow-inner">
          <button
            onClick={() => setActiveTab('replies')}
            className={`flex-1 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'replies'
                ? 'bg-gradient-to-r from-pink-500 to-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            <span>Smart Replies</span>
          </button>
          
          <button
            onClick={() => setActiveTab('openers')}
            className={`flex-1 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'openers'
                ? 'bg-gradient-to-r from-purple-500 to-indigo-605 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Opener Crafter</span>
          </button>

          <button
            onClick={() => setActiveTab('bios')}
            className={`flex-1 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'bios'
                ? 'bg-gradient-to-r from-orange-400 to-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Bio Builder</span>
          </button>

          <button
            onClick={() => setActiveTab('analyzer')}
            className={`flex-1 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'analyzer'
                ? 'bg-gradient-to-r from-teal-500 to-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Vibe Checklist</span>
          </button>

          <button
            onClick={() => setActiveTab('reviver')}
            className={`flex-1 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'reviver'
                ? 'bg-gradient-to-r from-red-400 to-rose-650 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Emergency Resuscitate</span>
          </button>

          <button
            onClick={() => setActiveTab('saved')}
            className={`flex-1 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'saved'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            <BookmarkCheck className="w-4 h-4" />
            <span>Vault ({savedList.length})</span>
          </button>
        </div>

        {/* Dynamic feature renders with global state save callbacks */}
        <main className="mb-14 min-h-[500px]">
          {activeTab === 'replies' && <ReplyGenerator onAddAnalysisLog={addLog} />}
          {activeTab === 'openers' && <OpenerGenerator onAddAnalysisLog={addLog} onSaveReply={handleSaveResponse} />}
          {activeTab === 'bios' && <BioWriter onAddAnalysisLog={addLog} />}
          {activeTab === 'analyzer' && <ChatAnalyzer onAddAnalysisLog={addLog} />}
          {activeTab === 'reviver' && <ChatReviver onAddAnalysisLog={addLog} />}
          {activeTab === 'saved' && <SavedResponses onAddAnalysisLog={addLog} savedList={savedList} onRemoveItem={handleRemoveSavedItem} />}
        </main>

        {/* Mobile bottom navigation (floating blur-glass layer) */}
        <nav className="fixed bottom-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-lg border-t border-slate-900 flex justify-around items-center py-2 lg:hidden">
          <button
            onClick={() => setActiveTab('replies')}
            className={`flex flex-col items-center justify-center py-1.5 transition-all text-center flex-1 cursor-pointer ${
              activeTab === 'replies' ? 'text-pink-500 animate-pulse' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <MessageCircle className="w-4.5 h-4.5" />
            <span className="text-[9px] font-semibold mt-1">Replies</span>
          </button>

          <button
            onClick={() => setActiveTab('openers')}
            className={`flex flex-col items-center justify-center py-1.5 transition-all text-center flex-1 cursor-pointer ${
              activeTab === 'openers' ? 'text-purple-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Sparkles className="w-4.5 h-4.5" />
            <span className="text-[9px] font-semibold mt-1">Openers</span>
          </button>

          <button
            onClick={() => setActiveTab('bios')}
            className={`flex flex-col items-center justify-center py-1.5 transition-all text-center flex-1 cursor-pointer ${
              activeTab === 'bios' ? 'text-orange-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <BioIcon className="w-4.5 h-4.5" />
            <span className="text-[9px] font-semibold mt-1">Bios</span>
          </button>

          <button
            onClick={() => setActiveTab('analyzer')}
            className={`flex flex-col items-center justify-center py-1.5 transition-all text-center flex-1 cursor-pointer ${
              activeTab === 'analyzer' ? 'text-teal-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Activity className="w-4.5 h-4.5" />
            <span className="text-[9px] font-semibold mt-1">Vibe Check</span>
          </button>

          <button
            onClick={() => setActiveTab('reviver')}
            className={`flex flex-col items-center justify-center py-1.5 transition-all text-center flex-1 cursor-pointer ${
              activeTab === 'reviver' ? 'text-red-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <RotateCcw className="w-4.5 h-4.5" />
            <span className="text-[9px] font-semibold mt-1">Revive</span>
          </button>

          <button
            onClick={() => setActiveTab('saved')}
            className={`flex flex-col items-center justify-center py-1.5 transition-all text-center flex-1 cursor-pointer relative ${
              activeTab === 'saved' ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <BookmarkCheck className="w-4.5 h-4.5" />
            <span className="text-[9px] font-semibold mt-1">Vault</span>
            {savedList.length > 0 && (
              <span className="absolute top-0.5 right-4 bg-pink-500 text-white rounded-full text-[8px] w-3 h-3 flex items-center justify-center font-bold">
                {savedList.length}
              </span>
            )}
          </button>
        </nav>

        {/* Real-time telemetry bottom log overlay */}
        <footer className="mt-16 grid grid-cols-1 md:grid-cols-12 gap-6 pt-8 border-t border-slate-900/80 items-start">
          {/* Telemetry log trace */}
          <div className="md:col-span-8 bg-slate-950/80 border border-slate-900 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-3.5 h-3.5 text-teal-400 animate-pulse" />
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
                Calibration Feed & Coach Log Trace
              </span>
            </div>
            <div className="font-mono text-[10px] text-slate-505 space-y-1.5 max-h-36 overflow-y-auto">
              {customLogs.map((log, index) => (
                <div key={index} className="flex gap-2 text-slate-400 hover:text-white transition-colors">
                  <span className="text-pink-500/80">&gt;</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Social Proof Note */}
          <div className="md:col-span-4 bg-gradient-to-br from-indigo-950/20 to-slate-950 p-4 rounded-2xl border border-slate-900/60 text-xs">
            <span className="font-bold text-white block mb-1 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-green-400" />
              100% Calibrated Social Coach
            </span>
            <p className="text-slate-500 leading-relaxed text-[11px]">
              Trained strictly on standard text psychology, light stakes sarcasm, and matching structures. Avoid cheese. Zero manipulation. Craft modern confident text streams cleanly.
            </p>
          </div>
        </footer>

      </div>
    </div>
  );
}
