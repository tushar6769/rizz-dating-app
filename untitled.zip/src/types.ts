/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Platform =
  | 'tinder'
  | 'bumble'
  | 'hinge'
  | 'instagram'
  | 'snapchat'
  | 'whatsapp'
  | 'texting';

export type Tone =
  | 'playful'
  | 'flirty'
  | 'confident'
  | 'sarcastic'
  | 'dry'
  | 'shy'
  | 'chaotic'
  | 'intellectual'
  | 'romantic'
  | 'bold';

export type Goal =
  | 'keep_going'
  | 'escalate'
  | 'get_number'
  | 'ask_out'
  | 'tease'
  | 'smooth_recovery';

export interface ReplyVariation {
  text: string;
  type: string; // e.g. playful, confident, funny, chill, bold, minimalist
}

export interface GeneratedReplyOutput {
  bestReply: string;
  alternatives: ReplyVariation[];
  whyItWorks: string;
  riskLevel: 'Safe' | 'Medium' | 'Bold';
  attractionScore: number; // 1-10
}

export interface AdvancedAnalysisOutput {
  interestScore: number; // 0-100
  attractionLevel: string; // high, medium, low
  boredomDetected: boolean;
  mixedSignals: boolean;
  flirtingIndicators: string[];
  conversationMistakes: string[];
  greenFlags: string[];
  redFlags: string[];
  suggestedDirection: string;
  nextBestMove: string;
}

export interface ReviveScenario {
  id: string;
  title: string;
  description: string;
  promptContext: string;
}
