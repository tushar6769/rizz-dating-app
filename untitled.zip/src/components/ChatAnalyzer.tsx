/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Sparkles, 
  Upload, 
  Image as ImageIcon, 
  Trash2, 
  Copy, 
  Check, 
  AlertTriangle, 
  Flame, 
  ShieldAlert, 
  TrendingUp, 
  Compass, 
  Activity, 
  RefreshCw,
  FileText
} from 'lucide-react';
import { AdvancedAnalysisOutput } from '../types.ts';

interface ChatAnalyzerProps {
  onAddAnalysisLog?: (log: string) => void;
}

const FUNNY_ANALYSIS_MESSAGES = [
  'Extracting texting patterns...',
  'Interpreting double-text timestamps...',
  'Calculating emotional investment metrics...',
  'Measuring sarcasm to sincerity ratio...',
  'Detecting micro-expressions in punctuation...',
  'Identifying low-interest warning signs...',
  'Formulating custom revival strategy...',
];

export function ChatAnalyzer({ onAddAnalysisLog }: ChatAnalyzerProps) {
  const [convoHistory, setConvoHistory] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [base64Data, setBase64Data] = useState<string | null>(null);
  
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState(FUNNY_ANALYSIS_MESSAGES[0]);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AdvancedAnalysisOutput | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startLoadingAnimation = () => {
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % FUNNY_ANALYSIS_MESSAGES.length;
      setLoadingMsg(FUNNY_ANALYSIS_MESSAGES[index]);
    }, 1200);
    return interval;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please provide an image file (PNG/JPG screenshot).');
      return;
    }
    setImageFile(file);
    setError(null);

    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = reader.result as string;
      setImagePreview(resultStr);
      // Strip metadata from data URL to get raw base64
      const base64 = resultStr.split(',')[1];
      setBase64Data(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
    setBase64Data(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!convoHistory.trim() && !base64Data) {
      setError('Provide either conversation history text or upload an exchange screenshot.');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    const intervalId = startLoadingAnimation();

    try {
      const response = await fetch('/api/rizzer/analyze-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          convoHistory: convoHistory || undefined,
          imageBase64: base64Data || undefined,
          imageMimeType: imageFile?.type || undefined,
        }),
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(errorJson.error || 'Server error occurred during vibe check.');
      }

      const data = await response.json();
      setResult(data);

      if (onAddAnalysisLog) {
        onAddAnalysisLog(
          `Analyzed chat conversation. Vibe check indicates: Interest ${data.interestScore || 70}%, ${
            data.attractionLevel === 'high' ? 'Strong Attraction' : data.attractionLevel === 'medium' ? 'Lukewarm status' : 'Low response depth'
          }.`
        );
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Something went wrong while running the vibe check.');
    } finally {
      clearInterval(intervalId);
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => {
      setCopiedText(null);
    }, 2000);
  };

  return (
    <div id="chat-analyzer-root" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Search & Inputs (7 Columns) */}
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 via-indigo-500 to-pink-500"></div>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Activity className="w-6 h-6 text-teal-400 animate-pulse" />
            <h2 className="text-xl font-bold text-white tracking-tight">Vibe & Flirting Analyzer</h2>
          </div>
          <span className="text-[10px] font-mono bg-teal-500/10 text-teal-400 border border-teal-500/20 px-2 py-1 rounded-lg">
            AI Vision Mode Active
          </span>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          Unsure if they love you or are just bored? Paste the chat text thread or upload a direct conversation screenshot. RizzAI scans response sizes, delay vibes, micro-tension, and double-text markers.
        </p>

        <form onSubmit={handleAnalyze} className="space-y-6">
          {/* File Upload component (Click & Drag Support) */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              Option A: Upload Chat Screenshot (Most Accurate)
            </label>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer ${
                isDragOver 
                  ? 'border-teal-500 bg-teal-500/10' 
                  : imagePreview 
                    ? 'border-indigo-500 bg-slate-950/40' 
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700'
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />

              {imagePreview ? (
                <div className="flex flex-col items-center gap-3">
                  <div className="relative w-32 h-40 rounded-lg overflow-hidden border border-slate-800 shadow-md">
                    <img src={imagePreview} alt="Screenshot preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        clearImage();
                      }}
                      className="absolute top-1.5 right-1.5 p-1.5 bg-rose-650 hover:bg-rose-700 text-white rounded-md transition-all cursor-pointer"
                      title="Remove image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-indigo-400 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Ready for advanced vision analysis
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono italic">
                    {imageFile?.name} ({Math.round(imageFile!.size / 1024)} KB)
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <div className="p-3 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-sm font-semibold text-slate-200 block">
                      Drag & drop a screenshot, or <span className="text-teal-400 font-bold">browse</span>
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      Works with Tinder, Hinge, Bumble, WhatsApp & DM screenshots
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Text input component */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              Option B: Paste Chat Transcript / Copy-Paste Thread
            </label>
            <textarea
              value={convoHistory}
              onChange={(e) => setConvoHistory(e.target.value)}
              placeholder={`Me: Hey! Loved your dog in that profile picture\nHer: haha thanks he's a menace\nMe: What kind of trouble has he gotten into recently?`}
              rows={5}
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 text-xs placeholder-slate-600 resize-none font-mono"
            />
          </div>

          <button
            type="submit"
            disabled={loading || (!convoHistory.trim() && !base64Data)}
            className="w-full py-4 px-6 bg-gradient-to-r from-teal-500 via-indigo-500 to-pink-500 hover:from-teal-600 hover:via-indigo-600 hover:to-pink-600 text-white font-bold rounded-xl text-sm transition-all duration-300 shadow-lg cursor-pointer transform hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Scanning: {loadingMsg}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Run Text & Vision Vibe Check</span>
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-4 rounded-xl bg-rose-950/30 border border-rose-900/30 text-rose-300 text-xs text-center">
            {error}
          </div>
        )}
      </div>

      {/* Outcome Analysis metrics (5 Columns) */}
      <div className="lg:col-span-5 flex flex-col gap-6">
        {result ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Compass className="w-32 h-32 text-teal-400 rotate-45" />
            </div>

            {/* Interest Score Gauge Header */}
            <div className="flex flex-col items-center justify-center py-6 border-b border-slate-800/80 mb-6">
              <div className="relative w-32 h-32 flex items-center justify-center">
                {/* SVG Radial Gauge */}
                <svg className="w-full h-full -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="52"
                    strokeWidth="8"
                    stroke="#0f172a"
                    fill="transparent"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="52"
                    strokeWidth="8"
                    stroke="url(#radialGlow)"
                    strokeDasharray={2 * Math.PI * 52}
                    strokeDashoffset={2 * Math.PI * 52 * (1 - result.interestScore / 100)}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                  <defs>
                    <linearGradient id="radialGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#2dd4bf" />
                      <stop offset="50%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="#f43f5e" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-extrabold text-white tracking-tighter">
                    {result.interestScore}%
                  </span>
                  <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest mt-0.5">
                    Interest
                  </span>
                </div>
              </div>

              {/* Status Badges Row */}
              <div className="flex flex-wrap gap-2 mt-5 justify-center">
                <span className={`px-2 py-1 rounded-md text-[10px] font-mono uppercase font-bold tracking-wider ${
                  result.attractionLevel === 'high' 
                    ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                    : result.attractionLevel === 'medium'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}>
                  Attraction: {result.attractionLevel}
                </span>

                {result.boredomDetected && (
                  <span className="px-2 py-1 rounded-md text-[10px] font-mono uppercase bg-red-550/10 text-red-400 border border-red-500/20 flex items-center gap-0.5">
                    <ShieldAlert className="w-3 h-3 text-red-400" />
                    Dry text alert
                  </span>
                )}

                {result.mixedSignals && (
                  <span className="px-2 py-1 rounded-md text-[10px] font-mono uppercase bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center gap-0.5">
                    <AlertTriangle className="w-3 h-3 text-purple-400" />
                    Mixed Signals
                  </span>
                )}
              </div>
            </div>

            {/* Tactical Strategy Guidance Block */}
            <div className="space-y-5 flex-1">
              {/* Recommended Action Move */}
              <div>
                <span className="text-xs font-bold text-teal-400 block mb-2 tracking-wide uppercase font-mono">
                  ★ Next Recommended Text Message
                </span>
                <div className="relative group bg-gradient-to-br from-teal-950/20 to-slate-950 border border-teal-500/20 rounded-2xl p-4 shadow-inner pr-12 transition-all hover:border-teal-500/40">
                  <p className="text-white text-xs leading-relaxed tracking-wide font-sans italic">
                    {result.nextBestMove || '"Tell me about your most chaotic weekend adventure."'}
                  </p>
                  <button
                    onClick={() => copyToClipboard(result.nextBestMove)}
                    className="absolute top-3 right-3 p-2 bg-slate-900 hover:bg-teal-600/50 text-slate-300 hover:text-white rounded-lg transition-all cursor-pointer border border-slate-800/80"
                    title="Copy response line"
                  >
                    {copiedText === result.nextBestMove ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* RizzAI Analysis explanation */}
              <div className="p-4 rounded-xl bg-indigo-500/5 border border-indigo-500/10">
                <h4 className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider font-mono mb-2 flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  Social Strategy Direction
                </h4>
                <p className="text-slate-300 text-xs leading-relaxed font-sans">
                  {result.suggestedDirection}
                </p>
              </div>

              {/* Green & Red Flag Rows */}
              <div className="grid grid-cols-2 gap-3">
                {/* Green flags */}
                <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3">
                  <span className="text-[10px] font-bold font-mono text-emerald-400 uppercase tracking-wider block mb-2">
                    ✔ Green Flags
                  </span>
                  {result.greenFlags && result.greenFlags.length > 0 ? (
                    <ul className="space-y-1">
                      {result.greenFlags.map((flag, idx) => (
                        <li key={idx} className="text-[10px] text-slate-300 leading-normal list-disc pl-1 select-none">
                          {flag}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <span className="text-[10px] text-slate-600 italic">No clear flags spotted</span>
                  )}
                </div>

                {/* Red Flags / Dry Indicators */}
                <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3">
                  <span className="text-[10px] font-bold font-mono text-rose-400 uppercase tracking-wider block mb-2">
                    ⚠ Red Flags
                  </span>
                  {result.redFlags && result.redFlags.length > 0 ? (
                    <ul className="space-y-1">
                      {result.redFlags.map((flag, idx) => (
                        <li key={idx} className="text-[10px] text-slate-300 leading-normal list-disc pl-1 select-none">
                          {flag}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <span className="text-[10px] text-slate-600 italic">No clear red flags spotted</span>
                  )}
                </div>
              </div>

              {/* Conversation Mistakes */}
              {result.conversationMistakes && result.conversationMistakes.length > 0 && (
                <div className="p-3 bg-rose-950/20 border border-rose-900/30 rounded-xl">
                  <span className="text-[10px] font-bold font-mono text-amber-500 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                    Crucial Mistakes Spot Checks
                  </span>
                  <ul className="space-y-1">
                    {result.conversationMistakes.map((mistake, idx) => (
                      <li key={idx} className="text-[10px] text-rose-300 list-inside list-disc">
                        {mistake}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Strategic Coaching Footnote */}
            <div className="border-t border-slate-800 pt-4 mt-6 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-orange-500 animate-bounce" />
                Vibe rating: Real intelligence
              </span>
              <span>RizzAI Vibe Check</span>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 rounded-3xl p-8 flex-1 flex flex-col items-center justify-center text-center backdrop-blur-sm min-h-[350px]">
            <FileText className="w-12 h-12 text-slate-800 mb-4" />
            <span className="text-sm font-semibold text-slate-350">Vibe Metrics Chamber</span>
            <p className="text-xs text-slate-500 mt-2 max-w-xs leading-relaxed">
              Dopamine tracking, green/red flags, and interest index will visual block here once vibe scanning completes.
            </p>
            <div className="flex gap-2 mt-6">
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                OCR Vision Enabled
              </span>
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                Textual Tension Scale
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
