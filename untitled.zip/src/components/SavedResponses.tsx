/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Trash2, 
  Copy, 
  Check, 
  TrendingUp, 
  Flame, 
  Share2,
  BookmarkCheck,
  RotateCcw
} from 'lucide-react';

export interface SavedItem {
  id: string;
  text: string;
  category: string;
  savedAt: string;
}

interface SavedResponsesProps {
  onAddAnalysisLog?: (log: string) => void;
  savedList: SavedItem[];
  onRemoveItem: (id: string) => void;
}

export function SavedResponses({ onAddAnalysisLog, savedList, onRemoveItem }: SavedResponsesProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [copyHistory, setCopyHistory] = useState<string[]>([]);

  useEffect(() => {
    // Populate simple copied history from localStorage
    try {
      const hist = localStorage.getItem('rizzflow_copied_hist');
      if (hist) {
        setCopyHistory(JSON.parse(hist));
      }
    } catch (e) {
      console.warn('Could not load copy history', e);
    }
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);

    // Append to simple copy history list
    const updatedHistory = [text, ...copyHistory.filter((item) => item !== text)].slice(0, 10);
    setCopyHistory(updatedHistory);
    localStorage.setItem('rizzflow_copied_hist', JSON.stringify(updatedHistory));

    setTimeout(() => setCopiedText(null), 1800);
    if (onAddAnalysisLog) {
      onAddAnalysisLog(`Copied saved item phrase: "${text.slice(0, 25)}..." to clipboard.`);
    }
  };

  const clearHistory = () => {
    setCopyHistory([]);
    localStorage.removeItem('rizzflow_copied_hist');
    if (onAddAnalysisLog) {
      onAddAnalysisLog('Cleared local clipboard copy history.');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
      {/* Saved list (7 Columns) */}
      <div className="lg:col-span-12 xl:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-indigo-500 to-emerald-500"></div>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <BookmarkCheck className="w-6 h-6 text-pink-500" />
            <h2 className="text-xl font-bold text-white tracking-tight">Your High-Value Rizz Vault</h2>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-pink-500/10 text-pink-400 border border-pink-500/20 uppercase font-semibold">
            {savedList.length} Items Saved
          </span>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          This is your private, local dictionary of calibrated responses, personalized bio drafts, and openers. Use them to maintain bulletproof conversational momentum on any dating app.
        </p>

        {savedList.length > 0 ? (
          <div className="space-y-4">
            {savedList.map((item) => (
              <div 
                key={item.id} 
                className="bg-slate-950 border border-slate-850 rounded-2xl p-4.5 hover:border-pink-500/30 transition-all duration-350 relative group"
              >
                <div className="flex items-center justify-between mb-3.5">
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded-lg bg-indigo-500/10 text-indigo-400 font-bold border border-indigo-500/20 uppercase tracking-widest">
                    {item.category}
                  </span>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] text-slate-500 font-mono">
                      {new Date(item.savedAt).toLocaleDateString()}
                    </span>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1 px-1.5 bg-slate-900/45 text-slate-500 hover:text-rose-450 border border-slate-800 rounded hover:bg-rose-500/10 transition-all cursor-pointer"
                      title="Remove from vault"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <p className="text-white text-xs leading-relaxed font-sans font-medium pr-12">
                  {item.text}
                </p>

                <div className="absolute bottom-4 right-4 opacity-50 group-hover:opacity-100 transition-all">
                  <button
                    onClick={() => copyToClipboard(item.text)}
                    className="p-2 bg-slate-900 hover:bg-pink-600/30 text-slate-300 hover:text-white rounded-lg transition-all border border-slate-800/80 cursor-pointer"
                    title="Copy phrase"
                  >
                    {copiedText === item.text ? <Check className="w-3.5 h-3.5 text-green-400 animate-pulse" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 rounded-3xl p-12 text-center min-h-[300px] flex flex-col items-center justify-center">
            <Heart className="w-12 h-12 text-slate-800 mb-4" />
            <span className="text-sm font-semibold text-slate-350 block">Vault is currently empty</span>
            <p className="text-xs text-slate-500 mt-2 max-w-xs leading-relaxed">
              When using the Reply Generator, Bio Writer, or Opener generators, tap "Save" to archive your absolute favorite AI creations.
            </p>
          </div>
        )}
      </div>

      {/* Recently Copied Section (5 Columns) */}
      <div className="lg:col-span-12 xl:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-500"></div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">Recently Copied Clippings</h3>
          </div>
          {copyHistory.length > 0 && (
            <button
              onClick={clearHistory}
              className="text-[10px] text-slate-500 hover:text-slate-300 font-mono flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Clear
            </button>
          )}
        </div>

        <p className="text-[11px] text-slate-400 mb-5 leading-normal">
          Running lists of items you've copied previously. Quick access for double-checks.
        </p>

        {copyHistory.length > 0 ? (
          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {copyHistory.map((histText, idx) => (
              <div 
                key={idx} 
                className="p-3 bg-slate-950 border border-slate-850 rounded-xl relative hover:border-emerald-500/20 transition-all duration-300 pr-10"
              >
                <p className="text-slate-300 text-[11px] font-sans leading-relaxed line-clamp-2">
                  {histText}
                </p>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(histText);
                    setCopiedText(histText);
                    setTimeout(() => setCopiedText(null), 1800);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-slate-900 border border-slate-850 hover:border-emerald-500 text-slate-400 hover:text-white rounded transition-all cursor-pointer"
                  title="Recopy text"
                >
                  {copiedText === histText ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 border border-slate-850 rounded-2xl bg-slate-950/20 text-center text-xs text-slate-600 font-mono italic">
            Clipboard is quiet... Go copy some high-grade rizz!
          </div>
        )}

        <div className="mt-6 p-3.5 rounded-xl bg-indigo-500/5 border border-indigo-500/10 text-[10px] text-slate-500 leading-normal flex gap-1.5">
          <Flame className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
          <span>Keep your confidence matching. Don't sound automated. Calibrate often and text carefree!</span>
        </div>
      </div>
    </div>
  );
}
