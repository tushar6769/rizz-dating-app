/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Copy, 
  Check, 
  RefreshCw,
  Award,
  BookOpen,
  Filter,
  CheckCheck,
  Edit2
} from 'lucide-react';

interface DatingBioContent {
  templateName: string;
  bioText: string;
  vibeDescription: string;
}

interface BioWriterProps {
  onAddAnalysisLog?: (log: string) => void;
}

const BIO_TEMPLATES = [
  { id: 'Funny', label: 'Humor & Sarcasm' },
  { id: 'Luxury lifestyle', label: 'Luxury & Lifestyle' },
  { id: 'Soft aesthetic', label: 'Soft Aesthetic' },
  { id: 'Gym personality', label: 'Gym & Core' },
  { id: 'Confident alpha', label: 'Bold Confident' },
  { id: 'Mysterious', label: 'Mysterious Aura' },
  { id: 'Intelligent/chill', label: 'Intelligent Chill' },
];

export function BioWriter({ onAddAnalysisLog }: BioWriterProps) {
  const [characterTraits, setCharacterTraits] = useState('');
  const [hobbies, setHobbies] = useState('');
  const [occupation, setOccupation] = useState('');
  const [selectedStyles, setSelectedStyles] = useState<string[]>(['Funny', 'Confident alpha']);
  const [editableBios, setEditableBios] = useState<DatingBioContent[] | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const toggleStyle = (styleId: string) => {
    if (selectedStyles.includes(styleId)) {
      if (selectedStyles.length > 1) {
        setSelectedStyles(selectedStyles.filter((s) => s !== styleId));
      }
    } else {
      setSelectedStyles([...selectedStyles, styleId]);
    }
  };

  const handleGenerateBio = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setEditableBios(null);

    try {
      const response = await fetch('/api/rizzer/generate-bio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          characterTraits: characterTraits || undefined,
          hobbies: hobbies || undefined,
          occupation: occupation || undefined,
          selectedStyles: selectedStyles
        })
      });

      if (!response.ok) {
        throw new Error('Bio composition failed on server calibration.');
      }

      const data = await response.json();
      setEditableBios(data.bios || []);

      if (onAddAnalysisLog) {
        onAddAnalysisLog(`Crafted ${data.bios?.length || 0} premium dating bio designs.`);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error occurred during bio design writer.');
    } finally {
      setLoading(false);
    }
  };

  const handleTextChange = (idx: number, newText: string) => {
    if (!editableBios) return;
    const copied = [...editableBios];
    copied[idx].bioText = newText;
    setEditableBios(copied);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 1800);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Input Module (7 Columns) */}
      <div className="lg:col-span-12 xl:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-pink-500 to-indigo-500"></div>

        <div className="flex items-center gap-2 mb-6">
          <Award className="w-6 h-6 text-orange-400" />
          <h2 className="text-xl font-bold text-white tracking-tight">Dating Profile Bio Architect</h2>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          Tired of generic dating profiles? Furnish a few personal variables, select your specific template vibes, and our elite copywriting system will construct a catchy profile designed to drive conversion and swipes.
        </p>

        <form onSubmit={handleGenerateBio} className="space-y-5">
          {/* Character traits input */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
                Character Traits / Vibes
              </label>
              <input
                type="text"
                value={characterTraits}
                onChange={(e) => setCharacterTraits(e.target.value)}
                placeholder="e.g. Sarcastic, ambitious, nerdy"
                className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 focus:outline-none focus:border-orange-500 text-xs placeholder-slate-650"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
                Your Job or Occupation
              </label>
              <input
                type="text"
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                placeholder="e.g. Architect, Barista, Designer"
                className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 focus:outline-none focus:border-orange-500 text-xs placeholder-slate-650"
              />
            </div>
          </div>

          {/* Passions/Hobbies */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              Daily Hobbies / Absolute Passions
            </label>
            <input
              type="text"
              value={hobbies}
              onChange={(e) => setHobbies(e.target.value)}
              placeholder="e.g. Vinyl records, cooking pasta, cold plunge, deep reading"
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 focus:outline-none focus:border-orange-500 text-xs placeholder-slate-650"
            />
          </div>

          {/* Persona Style selections */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-orange-400" />
              Toggle Target Template Moods
            </label>
            <div className="flex flex-wrap gap-2">
              {BIO_TEMPLATES.map((tpl) => {
                const isSelected = selectedStyles.includes(tpl.id);
                return (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => toggleStyle(tpl.id)}
                    className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-orange-500 to-pink-500 text-white border-transparent shadow shadow-orange-500/20'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    {tpl.label}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 px-6 bg-gradient-to-r from-orange-500 via-pink-500 to-indigo-500 hover:from-orange-600 hover:via-pink-600 hover:to-indigo-600 text-white font-bold rounded-2xl text-sm transition-all duration-300 shadow-lg cursor-pointer transform hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Designing Copywriting Drafts...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Write Elite App Profiles</span>
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-4 rounded-xl bg-rose-950/30 border border-rose-900/30 text-rose-300 text-xs text-center">
            {error}
          </div>
        )}
      </div>

      {/* Outcome Suggestions (5 Columns) */}
      <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-6">
        {editableBios ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col">
            <div className="flex justify-between items-center pb-4 border-b border-slate-800/80 mb-6 font-mono">
              <span className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-orange-400" />
                Dating Profile Outlines
              </span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-bold font-mono">
                Editable
              </span>
            </div>

            {/* Bios List */}
            <div className="space-y-6">
              {editableBios.map((bio, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-orange-405 bg-orange-500/10 px-2 py-0.5 border border-orange-500/20 rounded">
                      {bio.templateName}
                    </span>
                    <button
                      onClick={() => copyToClipboard(bio.bioText)}
                      className="px-2.5 py-1 text-[10px] font-bold font-mono bg-slate-950 hover:bg-orange-600 hover:text-white border border-slate-800 rounded text-slate-350 transition-all flex items-center gap-1 cursor-pointer"
                    >
                      {copiedText === bio.bioText ? (
                        <>
                          <CheckCheck className="w-3 h-3 text-green-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy Bio</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Vibe description footnote */}
                  <p className="text-[10px] text-slate-500 italic mb-1">
                     → Target audience: {bio.vibeDescription}
                  </p>

                  {/* Inline editable text area */}
                  <div className="relative">
                    <textarea
                      value={bio.bioText}
                      onChange={(e) => handleTextChange(idx, e.target.value)}
                      rows={4}
                      className="w-full relative z-10 p-3 bg-slate-950 hover:bg-slate-950/80 border border-slate-850 hover:border-slate-700 focus:border-orange-500 text-white rounded-xl text-xs font-sans leading-relaxed focus:outline-none transition-all placeholder-slate-700 resize-none"
                    />
                    <div className="absolute bottom-2.5 right-2.5 z-20 pointer-events-none text-slate-650 opacity-40">
                      <Edit2 className="w-3 h-3" />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Strategic Coaching Footnote */}
            <div className="border-t border-slate-800 pt-4 mt-6 flex items-center justify-between text-[10px] text-slate-450 font-mono">
              <span>✍ Tailor, click & copy instantly</span>
              <span>Dating Bio Matrix</span>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 rounded-3xl p-8 flex-1 flex flex-col items-center justify-center text-center backdrop-blur-sm min-h-[350px]">
            <Award className="w-12 h-12 text-slate-800 mb-4" />
            <span className="text-sm font-semibold text-slate-355">Bio Architect Safe</span>
            <p className="text-xs text-slate-500 mt-2 max-w-xs leading-relaxed">
              Unlock customized tinder, hinge and bumble profile bio content designed for immediate attention.
            </p>
            <div className="flex gap-2 mt-6">
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                Premium Hooks
              </span>
              <span className="text-[10px] text-slate-650 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                Whip Sarcasm
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
