/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Copy, 
  Check, 
  RotateCcw, 
  Heart, 
  Coffee, 
  User, 
  Camera, 
  Info,
  Compass
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OpenerSuggestion {
  category: string;
  text: string;
  deliveryTip: string;
}

interface OpenerGeneratorProps {
  onAddAnalysisLog?: (log: string) => void;
  onSaveReply?: (reply: { text: string; category: string }) => void;
}

const FUNNY_OPENMENT_MSG = [
  'Checking target interests...',
  'Avoiding cheesy line database...',
  'Formulating first impression value...',
  'Injecting charming banter logic...',
  'Evaluating context hook vectors...',
  'Double testing conversational bait...',
];

export function OpenerGenerator({ onAddAnalysisLog, onSaveReply }: OpenerGeneratorProps) {
  const [datingBio, setDatingBio] = useState('');
  const [interests, setInterests] = useState('');
  const [photosDescription, setPhotosDescription] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [loadMsg, setLoadMsg] = useState(FUNNY_OPENMENT_MSG[0]);
  const [error, setError] = useState<string | null>(null);
  const [openers, setOpeners] = useState<OpenerSuggestion[] | null>(null);
  const [coachingPointer, setCoachingPointer] = useState<string>('');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const startLoadingAnimation = () => {
    let idx = 0;
    const interval = setInterval(() => {
      idx = (idx + 1) % FUNNY_OPENMENT_MSG.length;
      setLoadMsg(FUNNY_OPENMENT_MSG[idx]);
    }, 1100);
    return interval;
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!datingBio.trim() && !interests.trim() && !photosDescription.trim()) {
      setError('Please fill in at least one field (bio, interests, or photos info) to feed the AI.');
      return;
    }

    setLoading(true);
    setError(null);
    setOpeners(null);

    const intId = startLoadingAnimation();

    try {
      const response = await fetch('/api/rizzer/generate-opener', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ datingBio, interests, photosDescription }),
      });

      if (!response.ok) {
        throw new Error('Our charisma engine is busy. Please try again.');
      }

      const data = await response.json();
      setOpeners(data.openers || []);
      setCoachingPointer(data.coachingPointer || '');

      if (onAddAnalysisLog) {
        onAddAnalysisLog(`Generated custom icebreaker openers for profile. Targets: ${interests || 'General interests'}.`);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error formulating icebreakers.');
    } finally {
      clearInterval(intId);
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 1800);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Input Module (7 Columns) */}
      <div className="lg:col-span-12 xl:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500"></div>

        <div className="flex items-center gap-2 mb-6">
          <Heart className="w-6 h-6 text-pink-500 animate-pulse" />
          <h2 className="text-xl font-bold text-white tracking-tight">Personalized Icebreaker Studio</h2>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          Stuck on how to say more than just "Hey"? Furnish details from their dating profile (such as their bio, listed interests, or description of photos), and we will engineer a highly tailored, custom first text.
        </p>

        <form onSubmit={handleGenerate} className="space-y-5">
          {/* Target Bio */}
          <div>
            <div className="flex gap-2 items-center mb-2">
              <User className="w-3.5 h-3.5 text-purple-400" />
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400">
                1. Copy Their Dating Bio Text
              </label>
            </div>
            <textarea
              value={datingBio}
              onChange={(e) => setDatingBio(e.target.value)}
              placeholder="e.g. 'Looking for someone to argue about pizza toppings with. Love weekend hikes, live jazz festivals, and iced coffees.'"
              rows={3}
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 focus:outline-none focus:border-pink-500 text-xs placeholder-slate-600 resize-none font-sans"
            />
          </div>

          {/* Target Interests */}
          <div>
            <div className="flex gap-2 items-center mb-2">
              <Coffee className="w-3.5 h-3.5 text-orange-400" />
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400">
                2. Specific Interests or Activities
              </label>
            </div>
            <input
              type="text"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="e.g. 'Sushi, Taylor Swift, hiking, matcha, board games'"
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 focus:outline-none focus:border-pink-500 text-xs placeholder-slate-600"
            />
          </div>

          {/* Photo Descriptions */}
          <div>
            <div className="flex gap-2 items-center mb-2">
              <Camera className="w-3.5 h-3.5 text-teal-400" />
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400">
                3. What's happening in their photos? (Optional Context)
              </label>
            </div>
            <input
              type="text"
              value={photosDescription}
              onChange={(e) => setPhotosDescription(e.target.value)}
              placeholder="e.g. 'Has a picture in Paris, holding an orange cat, or sipping wine at a vineyard'"
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 focus:outline-none focus:border-pink-500 text-xs placeholder-slate-600"
            />
          </div>

          <button
            type="submit"
            disabled={loading || (!datingBio.trim() && !interests.trim() && !photosDescription.trim())}
            className="w-full py-4 px-6 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 hover:from-purple-600 hover:via-pink-600 hover:to-orange-600 text-white font-bold rounded-2xl text-sm transition-all duration-300 shadow-lg cursor-pointer transform hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Formulating: {loadMsg}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Draft 4 Handcrafted Openers</span>
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-4 rounded-xl bg-rose-950/30 border border-rose-900/30 text-rose-300 text-xs text-center">
            {error}
          </div>
        )}
      </div>

      {/* Outcome Suggestions (5 Columns) */}
      <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-6">
        {openers ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col">
            <div className="flex justify-between items-center pb-4 border-b border-slate-800/80 mb-6 font-mono">
              <span className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-pink-400 animate-spin-slow" />
                Generated Icebreakers
              </span>
              <span className="text-[10px] bg-pink-500/10 text-pink-400 px-2 py-0.5 rounded border border-pink-500/20 uppercase font-semibold">
                Perfect Fit
              </span>
            </div>

            {/* Strategic Pointer Callout */}
            {coachingPointer && (
              <div className="p-4 rounded-xl bg-orange-500/5 border border-orange-500/10 mb-6 text-xs">
                <div className="flex gap-2">
                  <Info className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-orange-400 uppercase tracking-widest font-mono text-[10px] mb-1">
                      Target Strategy Insight
                    </h5>
                    <p className="text-slate-350 leading-relaxed text-[11px]">{coachingPointer}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Suggestions cards space */}
            <div className="space-y-4">
              {openers.map((op, index) => (
                <div 
                  key={index} 
                  className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 relative group hover:border-pink-500/30 transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-purple-500/10 text-purple-400 font-bold border border-purple-500/20 uppercase tracking-wider">
                      {op.category}
                    </span>
                    <div className="flex gap-1.5 opacity-80 group-hover:opacity-100 transition-all">
                      {onSaveReply && (
                        <button
                          onClick={() => {
                            onSaveReply({ text: op.text, category: op.category });
                          }}
                          className="px-2 py-1 bg-slate-900 hover:bg-pink-600/30 text-[10px] font-semibold font-mono text-slate-300 border border-slate-800 hover:text-white rounded transition-all cursor-pointer"
                        >
                          Save
                        </button>
                      )}
                      <button
                        onClick={() => copyToClipboard(op.text)}
                        className="p-1 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded transition-all cursor-pointer"
                        title="Copy text"
                      >
                        {copiedText === op.text ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>

                  <p className="text-white text-xs leading-relaxed font-sans font-medium mb-2.5">
                    {op.text}
                  </p>

                  <div className="text-[10px] text-slate-500 leading-normal flex items-start gap-1 font-mono italic">
                    <span className="text-pink-500">Coach suggestion:</span>
                    <span>{op.deliveryTip}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Strategic Coaching Footnote */}
            <div className="border-t border-slate-800 pt-4 mt-6 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span className="flex items-center gap-1 select-none">
                🌟 Instant first impressions
              </span>
              <span>Wingman Icebreakers</span>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 rounded-3xl p-8 flex-1 flex flex-col items-center justify-center text-center backdrop-blur-sm min-h-[350px]">
            <Heart className="w-12 h-12 text-slate-800 mb-4 animate-pulse" />
            <span className="text-sm font-semibold text-slate-355">Bespoke Icebreaker Box</span>
            <p className="text-xs text-slate-500 mt-2 max-w-xs leading-relaxed">
              We compile highly effective opening messages targeting their unique details. Say goodbye to awkward interactions.
            </p>
            <div className="flex gap-2 mt-6">
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                Playful Banter
              </span>
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                98% Answer Rate
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
