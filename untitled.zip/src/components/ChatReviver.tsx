/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Flame, 
  Copy, 
  Check, 
  ArrowRight, 
  Info, 
  RefreshCw,
  Zap,
  RotateCcw
} from 'lucide-react';

interface ReviveScenario {
  id: string;
  title: string;
  emoji: string;
  description: string;
  defaultNotes: string;
}

const PRESET_SCENARIOS: ReviveScenario[] = [
  {
    id: 'ghosted',
    title: 'Left on read / Ghosted',
    emoji: '👻',
    description: 'They read your message but disappeared. Silence lasted over 4 days.',
    defaultNotes: 'We had a good laugh, then I asked what she was doing over the weekend. Left on read for 4 days.'
  },
  {
    id: 'dry_reply',
    title: 'Dry texting / Low Effort',
    emoji: '🌵',
    description: 'They reply with one-word answers like "lol", "cool", or "nice".',
    defaultNotes: 'I wrote a fun story and they literally replied with "haha cool". Desperately need a pattern shift.'
  },
  {
    id: 'awkward_moment',
    title: 'Awkward silence / Joke flatline',
    emoji: '💩',
    description: 'You said something a bit too weird/intense and the vibe stalled.',
    defaultNotes: 'Made a joke about marrying them on the first date, they did not find it funny. Stall.'
  },
  {
    id: 'post_date_silence',
    title: 'Post-First-Date coldness',
    emoji: '☕',
    description: 'The date went well, but text momentum slowed down drastically.',
    defaultNotes: 'Had delicious coffee on Sunday. I texted "great meeting you" and got a very brief response. Silence since.'
  },
  {
    id: 'overtexted',
    title: 'Over-texting landmine',
    emoji: '📱',
    description: 'You double or triple-texted and now feel a bit too eager.',
    defaultNotes: 'Sent 3 rapid texts about a movie, now realizing I sounded super eager. Need a self-aware reset.'
  }
];

interface ChatReviverProps {
  onAddAnalysisLog?: (log: string) => void;
}

interface ReviveResult {
  situationSummary: string;
  bestReply: string;
  alternatives: {
    text: string;
    type: string;
    riskLevel: string;
  }[];
  strategicAdvice: string;
}

export function ChatReviver({ onAddAnalysisLog }: ChatReviverProps) {
  const [selectedScenario, setSelectedScenario] = useState<ReviveScenario>(PRESET_SCENARIOS[0]);
  const [customNotes, setCustomNotes] = useState(PRESET_SCENARIOS[0].defaultNotes);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ReviveResult | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const handleScenarioSelect = (scenario: ReviveScenario) => {
    setSelectedScenario(scenario);
    setCustomNotes(scenario.defaultNotes);
  };

  const handleRevive = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/rizzer/revive-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          situationType: selectedScenario.title,
          lastExchangeNotes: customNotes
        })
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Server error reviving conversation.');
      }

      const data = await response.json();
      setResult(data);

      if (onAddAnalysisLog) {
        onAddAnalysisLog(`Triggered Conversation Reviver desk for: "${selectedScenario.title}". Generated custom self-deprecating & light-hearted openers.`);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to trigger resuscitation charm.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => {
      setCopiedText(null);
    }, 2000);
  };

  return (
    <div id="chat-reviver-root" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Selection desk (7 Columns) */}
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-rose-500 to-indigo-500"></div>

        <div className="flex items-center gap-2 mb-6">
          <RotateCcw className="w-6 h-6 text-orange-400 animate-spin-slow" />
          <h2 className="text-xl font-bold text-white tracking-tight">Emergency Chat Resuscitation</h2>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          Stalled conversation? Double texted? RizzAI crafts high-comedy, low-pressure, visually intriguing, or slightly absurd icebreakers to revive the chat without sounding butt-hurt or defensive.
        </p>

        <form onSubmit={handleRevive} className="space-y-6">
          {/* Preset Buttons Grid */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              1. Select Stalled Scenario
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {PRESET_SCENARIOS.map((scen) => (
                <button
                  key={scen.id}
                  type="button"
                  onClick={() => handleScenarioSelect(scen)}
                  className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all duration-200 cursor-pointer ${
                    selectedScenario.id === scen.id
                      ? 'bg-gradient-to-br from-orange-500/10 to-rose-500/10 border-orange-500/50 text-white'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  <span className="text-xl">{scen.emoji}</span>
                  <div>
                    <span className="text-xs font-semibold block">{scen.title}</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5 leading-normal">{scen.description}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Context customization */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              2. Describe what happened (Be honest with RizzAI)
            </label>
            <textarea
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              placeholder="e.g. 'Left on read after inviting them out. Vibe was great before.'"
              rows={4}
              required
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 text-xs placeholder-slate-600 resize-none font-sans"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !customNotes.trim()}
            className="w-full py-4 px-6 bg-gradient-to-r from-orange-400 via-rose-500 to-indigo-500 hover:from-orange-500 hover:via-rose-600 hover:to-indigo-600 text-white font-bold rounded-xl text-sm transition-all duration-300 shadow-lg cursor-pointer transform hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Brewing Emergency Opener...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Revive Conversation Vibe</span>
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-4 rounded-xl bg-rose-950/30 border border-rose-900/30 text-rose-300 text-xs text-center">
            {error}
          </div>
        )}
      </div>

      {/* Strategic Outcome (5 Columns) */}
      <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-6 w-full">
        {result ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Zap className="w-32 h-32 text-orange-400 rotate-12" />
            </div>

            {/* Strategic strategy chosen title */}
            <div className="flex items-center gap-2 pb-4 border-b border-slate-800 mb-6">
              <Zap className="w-4 h-4 text-orange-400 animate-pulse" />
              <span className="text-xs font-mono uppercase text-slate-400">
                Resuscitation Strategy Chosen
              </span>
            </div>

            <p className="text-xs text-slate-350 leading-relaxed mb-6 font-mono bg-slate-950 p-3 rounded-lg border border-slate-800">
              {result.situationSummary}
            </p>

            {/* Premium Outcomes */}
            <div className="space-y-6 flex-1">
              {/* Best Emergency Opener */}
              <div>
                <span className="text-xs font-bold text-orange-400 block mb-2 tracking-wide uppercase font-mono">
                  ★ Recommended Launch Opener
                </span>
                <div className="relative group bg-gradient-to-br from-orange-950/40 to-slate-950 border border-orange-500/30 rounded-2xl p-4 shadow-inner pr-12 transition-all hover:border-orange-500/30">
                  <p className="text-white text-base leading-relaxed tracking-wide font-sans">
                    {result.bestReply}
                  </p>
                  <button
                    onClick={() => copyToClipboard(result.bestReply)}
                    className="absolute top-3 right-3 p-2 bg-slate-900 hover:bg-orange-600/50 text-slate-300 hover:text-white rounded-lg transition-all cursor-pointer border border-slate-800/80 hover:border-orange-500/30"
                    title="Copy best opener"
                  >
                    {copiedText === result.bestReply ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Strategic advice from coach */}
              <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/10">
                <div className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-[11px] font-bold text-amber-300 uppercase tracking-wider font-mono mb-1">
                      Why This Opener Shifts The Frame
                    </h4>
                    <p className="text-slate-350 text-xs leading-relaxed">
                      {result.strategicAdvice}
                    </p>
                  </div>
                </div>
              </div>

              {/* Strategic Variations */}
              <div>
                <span className="text-xs font-bold text-indigo-400 block mb-3 font-mono uppercase tracking-wider">
                  Alternative Safety Anchors
                </span>
                <div className="space-y-2.5">
                  {result.alternatives && result.alternatives.map((alt, idx) => (
                    <div
                      key={idx}
                      className="group relative bg-slate-950/80 border border-slate-800 hover:border-orange-500/20 rounded-xl p-3 pr-12 transition-all flex items-center justify-between"
                    >
                      <div className="flex-1 pr-4">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="inline-block text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                            {alt.type}
                          </span>
                          <span className={`inline-block text-[9px] font-mono px-1.5 py-0.5 rounded ${
                            alt.riskLevel === 'Safe' ? 'bg-green-500/10 text-green-400' : alt.riskLevel === 'Medium' ? 'bg-amber-400/10 text-amber-400' : 'bg-rose-500/10 text-rose-450'
                          }`}>
                            Risk: {alt.riskLevel}
                          </span>
                        </div>
                        <p className="text-slate-200 text-xs font-sans leading-relaxed">
                          {alt.text}
                        </p>
                      </div>
                      <button
                        onClick={() => copyToClipboard(alt.text)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 p-2 bg-slate-900/60 rounded-lg hover:bg-slate-800 transition-all border border-slate-800 cursor-pointer"
                        title="Copy text code"
                      >
                        {copiedText === alt.text ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Strategic Coaching Footnote */}
            <div className="border-t border-slate-800 pt-4 mt-6 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                Zero desperation metric verified
              </span>
              <span>RizzAI Resuscitate Desk</span>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 rounded-3xl p-8 flex-1 flex flex-col items-center justify-center text-center backdrop-blur-sm min-h-[350px]">
            <MessageSquare className="w-12 h-12 text-slate-800 mb-4" />
            <span className="text-sm font-semibold text-slate-350">Resuscitation Chamber</span>
            <p className="text-xs text-slate-500 mt-2 max-w-xs leading-relaxed">
              Targeted templates will produce safe-guarded openers with strategic framing right here.
            </p>
            <div className="flex gap-2 mt-6">
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                0% Creepiness Factor
              </span>
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                Playful Reset
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
