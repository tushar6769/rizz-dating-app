/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Copy, 
  Check, 
  MessageCircle, 
  Flame, 
  Info, 
  ArrowRight, 
  Compass, 
  ShieldCheck, 
  RefreshCw,
  Heart
} from 'lucide-react';
import { Platform, Tone, Goal, GeneratedReplyOutput } from '../types.ts';

interface ReplyGeneratorProps {
  onAddAnalysisLog?: (log: string) => void;
}

const PLATFORMS: { id: Platform; label: string; color: string; bg: string }[] = [
  { id: 'tinder', label: 'Tinder', color: 'from-pink-500 to-rose-500', bg: 'bg-rose-500/10 text-rose-350 border-rose-500/20' },
  { id: 'bumble', label: 'Bumble', color: 'from-amber-450 to-yellow-500', bg: 'bg-yellow-500/10 text-yellow-350 border-yellow-500/20' },
  { id: 'hinge', label: 'Hinge', color: 'from-purple-600 to-indigo-700', bg: 'bg-indigo-505/10 text-indigo-350 border-indigo-505/20' },
  { id: 'instagram', label: 'Instagram', color: 'from-pink-600 via-purple-500 to-orange-500', bg: 'bg-pink-500/10 text-pink-350 border-pink-500/20' },
  { id: 'whatsapp', label: 'WhatsApp', color: 'from-green-550 to-emerald-600', bg: 'bg-emerald-500/10 text-emerald-350 border-emerald-500/20' },
  { id: 'snapchat', label: 'Snapchat', color: 'from-yellow-300 to-yellow-450', bg: 'bg-yellow-400/10 text-yellow-350 border-yellow-400/20' },
  { id: 'texting', label: 'iMessage/SMS', color: 'from-blue-500 to-indigo-600', bg: 'bg-blue-500/10 text-blue-355 border-blue-500/20' },
];

const TONES: { id: Tone; label: string; emoji: string }[] = [
  { id: 'playful', label: 'Playful', emoji: '😜' },
  { id: 'flirty', label: 'Flirty', emoji: '😏' },
  { id: 'confident', label: 'Confident', emoji: '😎' },
  { id: 'sarcastic', label: 'Teasing', emoji: '😈' },
  { id: 'dry', label: 'Dry Wit', emoji: '😐' },
  { id: 'bold', label: 'High Stakes (Bold)', emoji: '🔥' },
  { id: 'intellectual', label: 'Clever/Deep', emoji: '🧠' },
  { id: 'romantic', label: 'Sweet', emoji: '🥰' },
];

const GOALS: { id: Goal; label: string; description: string }[] = [
  { id: 'keep_going', label: 'Keep it flowing', description: 'Maintain momentum with banter' },
  { id: 'escalate', label: 'Escalate vibe', description: 'Inject chemistry & tease' },
  { id: 'get_number', label: 'Secure phone/social', description: 'Transition off the dating app' },
  { id: 'ask_out', label: 'Lock in a date', description: 'Ask them out smoothly & casually' },
  { id: 'tease', label: 'Playful challenge', description: 'Put them on some fun probation' },
];

const FUNNY_LOADING_MESSAGES = [
  'Decoding text dynamics...',
  'Analyzing dopamine triggers...',
  'Sifting through social mechanics...',
  'Calibrating raw charisma metrics...',
  'Avoiding double-texting landmines...',
  'Generating high-calibre banter...',
  'Sprinkling effortless confidence...',
  'Reviewing text psychology books...',
];

export function ReplyGenerator({ onAddAnalysisLog }: ReplyGeneratorProps) {
  const [inputText, setInputText] = useState('');
  const [contextText, setContextText] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>('tinder');
  const [selectedTone, setSelectedTone] = useState<Tone>('playful');
  const [selectedGoal, setSelectedGoal] = useState<Goal>('keep_going');

  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState(FUNNY_LOADING_MESSAGES[0]);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<GeneratedReplyOutput | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const startLoadingAnimation = () => {
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % FUNNY_LOADING_MESSAGES.length;
      setLoadingMsg(FUNNY_LOADING_MESSAGES[index]);
    }, 1200);
    return interval;
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    const intervalId = startLoadingAnimation();

    try {
      const response = await fetch('/api/rizzer/generate-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: inputText,
          context: contextText,
          platform: selectedPlatform,
          tone: selectedTone,
          goal: selectedGoal,
        }),
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(errorJson.error || 'Server returned an error.');
      }

      const data = await response.json();
      setResult(data);

      if (onAddAnalysisLog) {
        onAddAnalysisLog(
          `Generated responses for on-app incoming message: "${inputText.slice(0, 30)}..." on ${selectedPlatform} with an Attraction value of ${data.attractionScore || 8}/10.`
        );
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Something went wrong while generating responses.');
    } finally {
      clearInterval(intervalId);
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => {
      setCopiedText(null);
    }, 2000);
  };

  return (
    <div id="reply-generator-root" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
      {/* Input panel (7 columns) */}
      <div className="lg:col-span-12 xl:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden backdrop-blur-lg">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-indigo-500 to-rose-500"></div>
        
        <div className="flex items-center gap-2 mb-6">
          <Sparkles className="w-6 h-6 text-pink-500 animate-pulse" />
          <h2 className="text-xl font-bold text-white tracking-tight font-sans">Smart Reply Studio</h2>
        </div>

        <form onSubmit={handleGenerate} className="space-y-6">
          {/* Platform selection */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              1. Platform Vibe
            </label>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map((plat) => (
                <button
                  key={plat.id}
                  type="button"
                  onClick={() => setSelectedPlatform(plat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all duration-300 cursor-pointer ${
                    selectedPlatform === plat.id
                      ? `bg-gradient-to-r ${plat.color} text-white border-transparent shadow-lg scale-105`
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  {plat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tone Selector */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              2. Delivery Tone
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {TONES.map((tone) => (
                <button
                  key={tone.id}
                  type="button"
                  onClick={() => setSelectedTone(tone.id)}
                  className={`p-2.5 rounded-xl text-xs font-medium border text-left flex items-center gap-2 transition-all cursor-pointer ${
                    selectedTone === tone.id
                      ? 'bg-gradient-to-r from-pink-500/20 to-indigo-500/20 text-white border-pink-500/50 shadow-md'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-250'
                  }`}
                >
                  <span>{tone.emoji}</span>
                  <span>{tone.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Goal selection */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              3. Next Objective
            </label>
            <div className="space-y-2">
              {GOALS.map((goal) => (
                <div
                  key={goal.id}
                  onClick={() => setSelectedGoal(goal.id)}
                  className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                    selectedGoal === goal.id
                      ? 'bg-indigo-500/10 text-white border-indigo-500/50'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center mt-0.5 ${
                    selectedGoal === goal.id ? 'border-pink-500 bg-pink-500' : 'border-slate-600'
                  }`}>
                    {selectedGoal === goal.id && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                  </div>
                  <div>
                    <p className={`text-xs font-semibold ${selectedGoal === goal.id ? 'text-white' : 'text-slate-300'}`}>
                      {goal.label}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{goal.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Message Prompt Input */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400">
                4. Their Last Message
              </label>
              <span className="text-[10px] text-slate-500 italic">Be literal & exact</span>
            </div>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder='e.g., "you seem like trouble" or "hey! what are you up to this weekend?" or "lol"'
              rows={3}
              required
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm placeholder-slate-600 resize-none font-sans"
            />
          </div>

          {/* Context Input */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400">
                5. Context / Inside Jokes (Optional)
              </label>
            </div>
            <input
              type="text"
              value={contextText}
              onChange={(e) => setContextText(e.target.value)}
              placeholder="e.g., 'Met on hinge yesterday, she likes spicy food' or 'We both love hiking'"
              className="w-full px-4 py-3 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500 text-xs placeholder-slate-600"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !inputText.trim()}
            className="w-full py-4 px-6 bg-gradient-to-r from-pink-500 via-indigo-500 to-rose-500 hover:from-pink-650 hover:via-indigo-650 hover:to-rose-650 text-white font-bold rounded-xl text-sm transition-all duration-300 shadow-lg cursor-pointer transform hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Rizzing: {loadingMsg}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Inject Charm & Get Replies</span>
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-4 rounded-xl bg-rose-950/30 border border-rose-900/30 text-rose-300 text-xs text-center">
            {error}
          </div>
        )}
      </div>

      {/* Outcome pane (5 columns) */}
      <div className="lg:col-span-12 xl:col-span-5 flex flex-col h-full gap-6">
        {result ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex-1 flex flex-col backdrop-blur-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <MessageCircle className="w-32 h-32 text-indigo-500 rotate-12" />
            </div>

            {/* Strategic Stats Header */}
            <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-6 font-mono">
              <span className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-indigo-400" />
                Calibration Report
              </span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 bg-slate-950/60 px-2 py-1 rounded-lg border border-slate-800">
                  <span className="text-[10px] font-mono text-slate-500">Risk:</span>
                  <span className={`text-[10px] font-bold uppercase ${
                    result.riskLevel === 'Safe' ? 'text-green-400' : result.riskLevel === 'Medium' ? 'text-amber-400' : 'text-rose-500'
                  }`}>
                    {result.riskLevel}
                  </span>
                </div>
                <div className="flex items-center gap-1 bg-gradient-to-r from-pink-500/10 to-rose-500/10 px-2 py-1 rounded-lg border border-rose-500/20">
                  <Flame className="w-3 h-3 text-pink-500" />
                  <span className="text-[10px] font-mono text-slate-405">Score:</span>
                  <span className="text-[10px] font-bold text-white">{result.attractionScore}/10</span>
                </div>
              </div>
            </div>

            {/* Premium Outcomes */}
            <div className="space-y-6 flex-1">
              {/* Best Reply Block */}
              <div>
                <span className="text-xs font-bold text-pink-400 block mb-2 tracking-wide uppercase font-mono">
                  ★ Best Calibration Response
                </span>
                <div className="relative group bg-gradient-to-br from-indigo-950/40 to-slate-950 border border-indigo-500/30 rounded-2xl p-4 shadow-inner pr-12 transition-all hover:border-pink-500/30">
                  <p className="text-white text-base leading-relaxed tracking-wide font-sans">
                    {result.bestReply}
                  </p>
                  <button
                    onClick={() => copyToClipboard(result.bestReply)}
                    className="absolute top-3 right-3 p-2 bg-slate-900 hover:bg-indigo-600/50 text-slate-300 hover:text-white rounded-lg transition-all cursor-pointer border border-slate-800/80 hover:border-indigo-500/30"
                    title="Copy best response"
                  >
                    {copiedText === result.bestReply ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Dynamic coach breakdown */}
              <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/10 mb-4">
                <div className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-[11px] font-bold text-amber-300 uppercase tracking-wider font-mono mb-1">
                      Why It Works (Social Dynamics)
                    </h4>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      {result.whyItWorks}
                    </p>
                  </div>
                </div>
              </div>

              {/* Strategic Variations */}
              <div>
                <span className="text-xs font-bold text-indigo-400 block mb-3 font-mono uppercase tracking-wider">
                  Alternative Variations
                </span>
                <div className="space-y-2.5">
                  {result.alternatives && result.alternatives.map((alt, idx) => (
                    <div
                      key={idx}
                      className="group relative bg-slate-950/80 border border-slate-800 hover:border-indigo-500/30 rounded-xl p-3 pr-12 transition-all flex items-center justify-between"
                    >
                      <div className="flex-1 pr-4">
                        <span className="inline-block text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 mb-1">
                          {alt.type}
                        </span>
                        <p className="text-slate-200 text-xs font-sans leading-relaxed">
                          {alt.text}
                        </p>
                      </div>
                      <button
                        onClick={() => copyToClipboard(alt.text)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 p-2 bg-slate-900/60 rounded-lg hover:bg-slate-800 transition-all border border-slate-800 cursor-pointer"
                        title="Copy text code"
                      >
                        {copiedText === alt.text ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Clean Coach Seal of Quality */}
            <div className="border-t border-slate-800 pt-4 mt-6 flex items-center justify-between font-mono">
              <div className="flex items-center gap-1 text-[10px] text-slate-500">
                <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
                Anti-Cringe Validation Active
              </div>
              <span className="text-[10px] text-pink-500 font-medium flex items-center gap-0.5">
                RizzAI calibrated <ArrowRight className="w-2.5 h-2.5" />
              </span>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 rounded-3xl p-8 flex-1 flex flex-col items-center justify-center text-center backdrop-blur-sm min-h-[350px]">
            <Heart className="w-12 h-12 text-slate-800 animate-pulse mb-4" />
            <span className="text-sm font-semibold text-slate-350">Preview Chamber</span>
            <p className="text-xs text-slate-500 mt-2 max-w-xs leading-relaxed">
              Your next highly infectious, confident responses will populate right here.
            </p>
            <div className="flex gap-2 mt-6">
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                100% Social Intelligence
              </span>
              <span className="text-[10px] text-slate-600 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                Witty Banter
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
